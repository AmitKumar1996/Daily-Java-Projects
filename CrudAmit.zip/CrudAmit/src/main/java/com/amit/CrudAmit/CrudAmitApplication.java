package com.amit.CrudAmit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudAmitApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudAmitApplication.class, args);
	}

}
