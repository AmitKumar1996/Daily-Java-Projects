package com.amit3.Amit31;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Amit31Application {

	public static void main(String[] args) {
		SpringApplication.run(Amit31Application.class, args);
	}

}
