package EmployeeAPI_05_04.EmployeeAPI_05_04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeApi0504ApplicationTests {

	@Test
	void contextLoads() {
	}

}
