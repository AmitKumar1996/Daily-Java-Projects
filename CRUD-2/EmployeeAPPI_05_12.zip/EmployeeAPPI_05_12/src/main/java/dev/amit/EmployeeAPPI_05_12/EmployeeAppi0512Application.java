package dev.amit.EmployeeAPPI_05_12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeAppi0512Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeAppi0512Application.class, args);
	}

}
