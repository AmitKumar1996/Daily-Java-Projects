package dev.amit.EmployeeAPPI_05_12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAppi0512ApplicationTests {

	@Test
	void contextLoads() {
	}

}
