package dev.xeni.xeni_rate_limiter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XeniRateLimiterApplicationTests {

	@Test
	void contextLoads() {
	}

}
