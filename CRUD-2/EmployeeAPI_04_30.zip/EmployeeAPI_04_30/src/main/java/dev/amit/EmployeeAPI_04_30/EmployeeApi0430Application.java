package dev.amit.EmployeeAPI_04_30;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeApi0430Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeApi0430Application.class, args);
	}

}
