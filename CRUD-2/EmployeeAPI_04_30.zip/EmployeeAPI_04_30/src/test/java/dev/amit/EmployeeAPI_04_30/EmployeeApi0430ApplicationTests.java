package dev.amit.EmployeeAPI_04_30;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeApi0430ApplicationTests {

	@Test
	void contextLoads() {
	}

}
