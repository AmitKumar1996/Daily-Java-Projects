package dev.amit.EmployeeAPI_05_02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeApi0502Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeApi0502Application.class, args);
	}

}
