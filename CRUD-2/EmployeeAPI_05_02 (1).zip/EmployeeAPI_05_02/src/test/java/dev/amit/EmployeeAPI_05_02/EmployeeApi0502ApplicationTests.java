package dev.amit.EmployeeAPI_05_02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeApi0502ApplicationTests {

	@Test
	void contextLoads() {
	}

}
