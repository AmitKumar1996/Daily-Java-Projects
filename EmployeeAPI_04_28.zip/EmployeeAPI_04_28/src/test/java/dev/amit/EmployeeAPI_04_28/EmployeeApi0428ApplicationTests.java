package dev.amit.EmployeeAPI_04_28;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeApi0428ApplicationTests {

	@Test
	void contextLoads() {
	}

}
