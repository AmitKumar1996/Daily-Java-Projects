package dev.Amit.EmployeeAPICRUD_04_27;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeApicrud0427Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeApicrud0427Application.class, args);
	}

}
