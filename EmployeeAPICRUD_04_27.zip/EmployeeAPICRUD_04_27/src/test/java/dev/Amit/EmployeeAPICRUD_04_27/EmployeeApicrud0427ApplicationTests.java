package dev.Amit.EmployeeAPICRUD_04_27;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeApicrud0427ApplicationTests {

	@Test
	void contextLoads() {
	}

}
