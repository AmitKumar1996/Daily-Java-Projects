package dev.Amit.EmployeeAPICRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeApicrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
