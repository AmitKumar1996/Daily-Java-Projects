package com.amit.CrudAmit2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudAmit2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
