package com.amit.CrudAmit2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudAmit2Application {

	public static void main(String[] args) {
		SpringApplication.run(CrudAmit2Application.class, args);
	}

}
